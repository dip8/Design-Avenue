<?php 
//error_reporting(0);
include('dbConnection.php');
	
	require '../PHPMailer/PHPMailerAutoload.php';
	require '../PHPMailer/class.phpmailer.php';
	require '../PHPMailer/class.smtp.php';
	
	
	$smtp_username = "dipaklokhande81@gmail.com"; // SMTP username
	$smtp_password = "";  // SMTP password
	
	$activation_from = "dipaklokhande81@gmail.com"; // activation set From mail-id
	
?>
