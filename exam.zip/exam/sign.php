<?php
include_once 'dbConnection.php';
ob_start();
$name = $_POST['name'];
$name= ucwords(strtolower($name));
$email = $_POST['email'];
$password = $_POST['password'];
$mob = $_POST['mob'];
$gender = $_POST['gender'];
$state = $_POST['state'];
$city = $_POST['city'];

$name = stripslashes($name);
$name = addslashes($name);
$name = ucwords(strtolower($name));
$gender = stripslashes($gender);
$gender = addslashes($gender);
$email = stripslashes($email);
$email = addslashes($email);
$state = stripslashes($state);
$state = addslashes($state);
$city = stripslashes($city);
$city = addslashes($city);
$mob = stripslashes($mob);
$mob = addslashes($mob);

$password = stripslashes($password);
$password = addslashes($password);
$password = md5($password);

$q3=mysqli_query($con,"INSERT INTO user VALUES  ('$name' , '$gender' ,'$email' ,'$mob', '$password', '$city', '$state')");
if($q3)
{
session_start();
$_SESSION["email"] = $email;
$_SESSION["name"] = $name;

header("location:mail.php");
header("location:index.php?q7=User Added Successfully..");
}
else
{
header("location:index.php?q7=Email Already Registered!!!");
}
ob_end_flush();
?>