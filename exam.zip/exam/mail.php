<?php
error_reporting( E_ALL );

include('send_mail_variables.php');
 $email_id=$_GET['email'];
 $name=$_GET['name'];
 $message="user register";
 $subject="User Register Confromation";
 $project_name="DemoExam";
 $msg_body="User Added Successfully.. Please log in"; 			

		ob_start();
		
	
			try{							
			$mail             = new PHPMailer();
			$body=$msg_body;
			//$mail->IsSMTP();
			$mail->Host       = "smtp.sendgrid.net";
			$mail->SMTPAuth   = true;
			$mail->SMTPSecure = 'tls';   
			$mail->Port 	  = 587;
			$mail->Username   = ""; 
			$mail->Password   = "";  
			$mail->AddReplyTo($email_id);
			$mail->Subject    = $subject;
			$mail->MsgHTML($body);
			$address 		  =$email_id;
			$mail->AddAddress($address);
			$mail->Send();
			  echo "<script>alert('Mail Send Successfully.');window.location.href = 'index.php';</script>";
			} catch (phpmailerException $e) {
			  echo $e->errorMessage(); //Pretty error messages from PHPMailer
			} catch (Exception $e) {
			  echo $e->getMessage(); //Boring error messages from anything else!
			}					
							
		 	
?>
